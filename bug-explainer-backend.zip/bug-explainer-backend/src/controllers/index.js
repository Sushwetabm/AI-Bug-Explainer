const authController = require("./authController");
const codeAnalysisController = require("./codeAnalysisController");
const userController = require("./userController");

module.exports = {
  authController,
  codeAnalysisController,
  userController,
};
