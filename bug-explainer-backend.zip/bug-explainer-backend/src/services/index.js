module.exports = {
  authService: require("./authService"),
  analysisService: require("./analysisService"),
  //mlService: require("./mlService"),
};
