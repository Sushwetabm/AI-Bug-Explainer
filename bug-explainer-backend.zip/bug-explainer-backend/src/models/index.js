const User = require("./User");
const BugReport = require("./BugReport");
const CodeAnalysis = require("./CodeAnalysis");

module.exports = {
  User,
  BugReport,
  CodeAnalysis,
};
